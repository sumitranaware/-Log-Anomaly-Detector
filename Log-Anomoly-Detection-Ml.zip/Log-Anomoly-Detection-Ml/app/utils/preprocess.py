import re
from typing import List, Union
from datetime import datetime, timezone
import pandas as pd

from app.schemas.log_entry import LogEntry

_DIGITS_RE = re.compile(r"\d")
_UPPER_RE = re.compile(r"[A-Z]")
_ERROR_WORDS = re.compile(r"\b(error|exception|fail|timeout|unavailable|panic|crash)\b", re.IGNORECASE)


def _parse_timestamp(ts: Union[str, None]) -> datetime:
    if ts is None:
        return datetime.now(timezone.utc)
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except Exception:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
            try:
                return datetime.strptime(ts, fmt).replace(tzinfo=timezone.utc)
            except Exception:
                continue
        return datetime.now(timezone.utc)


def _digit_count(s: str) -> int:
    return len(_DIGITS_RE.findall(s or ""))


def _upper_ratio(s: str) -> float:
    if not s:
        return 0.0
    ups = len(_UPPER_RE.findall(s))
    return ups / max(1, len(s))


def _has_error_word(s: str) -> bool:
    return bool(_ERROR_WORDS.search(s or ""))


def to_dataframe(entries: List[Union[LogEntry, dict]]):
    rows = []
    for e in entries:
        if isinstance(e, dict):
            ts = e.get("timestamp")
            msg = e.get("message", "")
            level = e.get("level", "INFO")
        else:  
            ts = e.timestamp
            msg = e.message or ""
            level = e.level.value if hasattr(e.level, "value") else str(e.level)

        dt = _parse_timestamp(ts)

        rows.append({
            "timestamp_iso": dt.isoformat(),
            "level": str(level).upper(),
            "message": msg,
            "hour": dt.hour,
            "day_of_week": dt.weekday(),
            "msg_len": len(msg),
            "digit_count": _digit_count(msg),
            "upper_ratio": _upper_ratio(msg),
            "has_error": 1 if _has_error_word(msg) else 0,
        })

    df = pd.DataFrame(rows)

    cols = ["timestamp_iso", "level", "message", "hour", "day_of_week",
            "msg_len", "digit_count", "upper_ratio", "has_error"]

    for c in cols:
        if c not in df.columns:
            df[c] = 0

    return df[cols]

