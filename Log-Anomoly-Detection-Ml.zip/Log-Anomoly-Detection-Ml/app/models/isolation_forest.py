from typing import List, Dict, Any, Optional, Union
import os
import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import IsolationForest
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.feature_extraction.text import HashingVectorizer

from app.schemas.log_entry import LogEntry
from app.schemas.anomaly import Anomaly
from app.utils.preprocess import to_dataframe


class IsoForestAnomalyModel:
    def __init__(
        self,
        contamination: float = 0.20,
        n_estimators: int = 200,
        random_state: int = 42,
        model_path: str = "model/isoforest.joblib",
    ):
        self.contamination = contamination
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.model_path = model_path
        self._pipeline: Optional[Pipeline] = None
        self.level_thresholds: Dict[str, float] = {}
        self.global_threshold: Optional[float] = None

    def _build_pipeline(self) -> Pipeline:
        text_transform = HashingVectorizer(
            n_features=2**12,
            alternate_sign=False,
            norm="l2",
            ngram_range=(1, 2),
        )

        preprocessor = ColumnTransformer(
            transformers=[
                ("msg", text_transform, "message"),
                ("lvl", OneHotEncoder(handle_unknown="ignore"), ["level"]),
                ("num", "passthrough", [
                    "hour", "day_of_week", "msg_len",
                    "digit_count", "upper_ratio", "has_error"
                ]),
            ],
            remainder="drop",
            sparse_threshold=0.3,
        )

        clf = IsolationForest(
            n_estimators=self.n_estimators,
            contamination=self.contamination,
            random_state=self.random_state,
            n_jobs=-1,
        )

        return Pipeline([
            ("prep", preprocessor),
            ("clf", clf),
        ])

    def fit(self, entries: Union[List[LogEntry], pd.DataFrame]) -> Dict[str, Any]:
     """Train on a list of LogEntry or a pandas DataFrame with required columns."""
     if isinstance(entries, list):
        df = to_dataframe(entries)
     else:
        df = entries.copy()

    # Build and fit pipeline
     self._pipeline = self._build_pipeline()
     self._pipeline.fit(df)

    # Compute scores
     Xtr = self._pipeline["prep"].transform(df)
     scores = self._pipeline["clf"].decision_function(Xtr)

    # --- NEW: initialize per-level + global thresholds ---
     self.level_thresholds = {}
     contamination = float(self.contamination)

     for lvl in df["level"].unique():
        mask = (df["level"] == lvl)
        if mask.sum() == 0:
            continue
        thr = float(pd.Series(scores[mask]).quantile(contamination))
        self.level_thresholds[lvl] = thr

    # Global fallback threshold if level not seen during training
     self.global_threshold = float(pd.Series(scores).quantile(contamination))

    # Return metrics for monitoring
     metrics = {
        "n_samples": int(len(df)),
        "score_mean": float(np.mean(scores)),
        "score_std": float(np.std(scores)),
        "global_threshold": self.global_threshold,
        "per_level_thresholds": self.level_thresholds,
    }
     return metrics

    def is_ready(self) -> bool:
        return self._pipeline is not None

    def predict(self, entries: Union[List[LogEntry], pd.DataFrame]) -> List[Anomaly]:
        if not self.is_ready():
            raise RuntimeError("Model is not trained")

        # 1. Build DataFrame, normalize levels, reset index
        df = to_dataframe(entries).copy()
        df["level"] = df["level"].astype(str).str.upper()
        df = df.reset_index(drop=True)

        # 2. Transform & get model outputs
        Xt = self._pipeline["prep"].transform(df)
        raw = self._pipeline["clf"].predict(Xt)            # 1 or -1
        dec = self._pipeline["clf"].decision_function(Xt)  # higher = more normal

        # 3. Build simple 0..1 score (optional)
        s = pd.Series(dec, index=df.index)
        rank = s.rank(method="average")
        anomaly_score = ((len(s) - rank) / max(1, len(s) - 1)).clip(0.0, 1.0)

        out: List[Anomaly] = []
        for i, row in df.iterrows():
            # i is 0..N-1 regardless of original index
            is_anom = (raw[i] == -1)  # True exactly when IsolationForest flags an outlier

            out.append(Anomaly(
                is_anomaly=is_anom,
                score=float(anomaly_score.iloc[i]),
                level=row["level"],
                message=row["message"],
                timestamp=row["timestamp_iso"],
                features={
                    "hour": int(row["hour"]),
                    "day_of_week": int(row["day_of_week"]),
                    "msg_len": int(row["msg_len"]),
                    "digit_count": int(row["digit_count"]),
                    "upper_ratio": float(row["upper_ratio"]),
                    "has_error": bool(row["has_error"]),
                },
            ))

        return out

    def save(self) -> str:
        if not self.is_ready():
            raise RuntimeError("Model not trained; Nothing to save")

        os.makedirs(os.path.dirname(self.model_path) or ".", exist_ok=True)
        joblib.dump({
            "pipeline": self._pipeline,
            "level_thresholds": self.level_thresholds,
            "global_threshold": self.global_threshold
        }, self.model_path)
        return self.model_path

    def load(self) -> None:
        if not os.path.exists(self.model_path):
            self._pipeline = None
            return

        data = joblib.load(self.model_path)
        if isinstance(data, dict):
            # restored saved pipeline + thresholds
            self._pipeline = data["pipeline"]
            self.level_thresholds = data.get("level_thresholds", {})
            self.global_threshold = data.get("global_threshold", None)
        else:
            # backward compatibility if only pipeline was saved
            self._pipeline = data
            self.level_thresholds = {}
            self.global_threshold = None
