from pydantic import BaseModel, Field, field_validator
from typing import Optional, Dict, Any
from enum import Enum
from datetime import datetime


class LogLevel(str,Enum):
    TRACE="TRACE"
    DEBUG="DEBUG"
    INFO="INFO"
    WARN="WARN"
    ERROR="ERROR"
    FATAL="FATAL"

class LogEntry(BaseModel):
    timestamp: Optional[str]=Field(
        default=None,
        
    )
    level:LogLevel=Field(description="Log level")
    message:str=Field(description="Log Message")
    metadata:Optional[Dict[str,Any]]=Field(default=None,description="Optional extra fields")

    @field_validator("timestamp")
    @classmethod
    def validate_ts(cls,v):
        if v is None:
            return v
        
        if isinstance(v,str):
            try:
                datetime.fromisoformat(v.replace("2","+00:00"))
            except Exception:
                pass
        return v