from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional

class Anomaly(BaseModel):
    is_anomaly:bool=Field(description="True if the entry is anomalous")
    score:float=Field (ge=0.0,le=1.0,description="Relative anomaly score (higher = more anomalous)")
    level:str
    message:str
    timestamp:Optional[str]=None
    features:Dict[str,Any]

class TrainResult(BaseModel):
    message:str
    metrics:Dict[str,Any]


class DetectResult(BaseModel):
    count:int 
    anomalies:List[Anomaly]