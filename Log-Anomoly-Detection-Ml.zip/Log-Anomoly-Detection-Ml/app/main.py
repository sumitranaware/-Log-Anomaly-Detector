import traceback
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List
import requests
from datetime import datetime
import os 

from app.schemas.log_entry import LogEntry
from app.schemas.anomaly import DetectResult
from app.models.isolation_forest import IsoForestAnomalyModel
from app.config import settings
from app.utils.preprocess import to_dataframe  # for model.fit/predict safety

app = FastAPI(
    title="Log Anomaly ML",
    version="1.0.0",
    description="FastAPI service for log anomaly detection using Isolation Forest."
)

SPRING_LOGS_URL = "http://localhost:8081/api/logs"

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOW_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model = IsoForestAnomalyModel(
    contamination=settings.CONTAMINATION,
    n_estimators=settings.N_ESTIMATORS,
    random_state=settings.RANDOM_STATE,
    model_path=settings.MODEL_PATH,
)

@app.on_event("startup")
def startup_event():
    try:
        model.load()
    except Exception:
        pass

@app.get("/health")
def health():
    return {"status": "ok", "model_ready": model.is_ready()}


def normalize_log(log) -> dict:
    """Ensure log is a dict with consistent keys."""
    if hasattr(log, "dict"):
        log = log.dict()
    if not isinstance(log, dict):
        raise TypeError(f"log_entry must be a dictionary, got {type(log)}")
    if "logLevel" in log and "level" not in log:
        log["level"] = log.pop("logLevel")
    if isinstance(log.get("timestamp"), (int, float)):
        log["timestamp"] = datetime.utcfromtimestamp(log["timestamp"] / 1000).isoformat() + "Z"
    log.setdefault("anomalous", None)
    log.setdefault("anomalyScore", None)
    log.setdefault("anomalyReason", None)
    return log


def fetch_all_logs() -> List[dict]:
    """Fetch logs from Spring Boot and normalize them."""
    resp = requests.get(SPRING_LOGS_URL)
    resp.raise_for_status()
    data = resp.json()
    if isinstance(data, dict) and "content" in data:
        raw_logs = data["content"]
    elif isinstance(data, list):
        raw_logs = data
    else:
        raise ValueError(f"Unexpected log format: {type(data)}")
    if not raw_logs:
        raise ValueError("No logs returned from Spring Boot")
    return [normalize_log(log) for log in raw_logs]


@app.post("/train")
def train():
    try:
        print("DEBUG: Fetching logs for training...")
        logs = fetch_all_logs()
        print(f"DEBUG: Retrieved {len(logs)} logs")
        model.fit(logs)  # to_dataframe inside model will handle dicts
        print("DEBUG: Model training complete")
        return {"message": f"Training complete with {len(logs)} log entries"}
    except Exception as e:
        print("TRAIN ERROR:", e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/detect", response_model=DetectResult)
def detect(entries: List[LogEntry]):
    try:
        if not entries:
            raise HTTPException(status_code=400, detail="No data provided")
        if not model.is_ready():
            if not settings.AUTO_TRAIN_ON_DETECT:
                raise HTTPException(
                    status_code=409,
                    detail="Model not trained. Train first or enable AUTO_TRAIN_ON_DETECT."
                )
            print("DEBUG: Auto-training model from Spring Boot logs...")
            logs = fetch_all_logs()
            print(f"DEBUG: Retrieved {len(logs)} logs for auto-train")
            model.fit(logs)
            print("DEBUG: Auto-training complete")
        normalized_entries = [normalize_log(e) for e in entries]
        print(f"DEBUG: Running prediction on {len(normalized_entries)} entries")
        preds = model.predict(normalized_entries)
        print("DEBUG: Prediction complete")
        return DetectResult(count=len(preds), anomalies=preds)
    except HTTPException:
        raise
    except Exception as e:
        print("DETECT ERROR:", e)
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/model/save")
def save_model():
    if not model.is_ready():
        raise HTTPException(status_code=409, detail="Model not trained")
    path = model.save()
    return {"message": "Model saved.", "path": path}


@app.post("/model/load")
def load_model():
    model.load()
    if not model.is_ready():
        raise HTTPException(status_code=404, detail=f"Model not found at {settings.MODEL_PATH}")
    return {"message": "Model loaded", "path": settings.MODEL_PATH}

LOG_FILE_PATH = r"C:\Users\SumitRanaware\OneDrive - Atyeti Inc\Desktop\-Log-Anomaly-Detector\Log-Anomoly-Detectiong-Spring\Log-Anomoly-Detectiong-Spring\log\app.log"

@app.get("/detect/fromfile")
def detect_from_file():
    if not os.path.exists(LOG_FILE_PATH):
        return {"error": f"Log file not found at {LOG_FILE_PATH}"}

    entries = []
    with open(LOG_FILE_PATH, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            # simple parser for "timestamp LEVEL message"
            try:
                parts = line.split(" ", 2)  
                ts_str = f"{parts[0]} {parts[1]}"
                level = parts[2].split()[0]
                message = parts[2][len(level):].strip()

                entry = {
                    "timestamp": datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S").isoformat() + "Z",
                    "level": level,
                    "message": message,
                    "metadata": {"source": "file"}
                }
                entries.append(entry)
            except Exception as e:
                print(f"Skipping unparsable line: {line} ({e})")

    if not entries:
        return {"error": "No valid log lines found in file"}

    preds = model.predict(entries)

    return {
        "file": LOG_FILE_PATH,
        "count": len(preds),
        "anomalies": preds
    }